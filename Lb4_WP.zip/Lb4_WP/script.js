const newsData = [
    { src: "photo/img16.jpg" }, { src: "photo/img17.jpg" },
    { src: "photo/img18.jpg" }, { src: "photo/img19.jpg" },
    { src: "photo/img20.jpg" }, { src: "photo/img21.jpg" },
    { src: "photo/img22.jpg" }, { src: "photo/img23.jpg" },
    { src: "photo/img24.jpg" }, { src: "photo/img25.jpg" },
    { src: "photo/img26.jpg" }, { src: "photo/img27.jpg" }
];

const container = document.getElementById('news-container');
const btn = document.getElementById('load-more');

let currentIndex = 0;
const itemsPerPage = 3; 
let isLoading = false; // Ключовий запобіжник від "нескінченних" дублів

function createNewsCard(item, indexInChunk) {
    const card = document.createElement('div'); // [cite: 16, 46]
    card.classList.add('gallery-card'); // [cite: 14]

    // Анімація появи
    card.style.animationDelay = `${indexInChunk * 0.1}s`;

    const img = document.createElement('img');
    img.src = item.src;
    img.alt = "Нове фото";
    
    card.appendChild(img); // 
    return card;
}

const maxItems = 36; // Максимальна кількість карток 
function renderNews() {

    if (isLoading || currentIndex >= maxItems) {
    return; 
    }
    
    isLoading = true; // Блокуємо повторне спрацювання

    for (let i = 0; i < itemsPerPage; i++) {
        const item = newsData[currentIndex % newsData.length];
        const card = createNewsCard(item, i);
        container.appendChild(card); // Додаємо в КІНЕЦЬ контейнера 
        currentIndex++;
    }

    // Невелика затримка перед розблокуванням, щоб скрол встиг "відійти" від низу
    setTimeout(() => {
        isLoading = false;
    }, 500); 
}

// 1. Подія кліку 
btn.addEventListener('click', renderNews);

// 2. Виправлена логіка скролу 
window.addEventListener('scroll', () => {
    const scrollPosition = window.innerHeight + window.pageYOffset;
    const pageHeight = document.documentElement.scrollHeight;

    // Збільшуємо зону спрацювання: 
    // Тепер завантаження почнеться, коли до низу залишиться 600px (а не 100)
    if (scrollPosition >= pageHeight - 2300) {
        renderNews();
    }
});

// Початкове налаштування анімацій 
window.addEventListener('DOMContentLoaded', () => {
    const staticCards = document.querySelectorAll('#news-container .gallery-card');
    staticCards.forEach((card, index) => {
        card.style.animationDelay = `${(index % 12) * 0.1}s`;
    });
});