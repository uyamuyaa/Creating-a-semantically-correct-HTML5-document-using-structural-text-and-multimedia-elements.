import NewsCard from './components/NewsCard.js';
const { createApp } = Vue;

createApp({
    components: {
        'news-card': NewsCard
    },
    data() {
        return {
            currentPage: 1,
            pageSize: 3,
            newsList: [
                { id: 1, title: 'Новина 1', image: 'photo/img4.jpg' },
                { id: 2, title: 'Новина 2', image: 'photo/img5.jpg' },
                { id: 3, title: 'Новина 3', image: 'photo/img6.jpg' },
                { id: 4, title: 'Новина 4', image: 'photo/img7.jpg' },
                { id: 5, title: 'Новина 5', image: 'photo/img8.jpg' },
                { id: 6, title: 'Новина 6', image: 'photo/img9.jpg' },
                { id: 7, title: 'Новина 7', image: 'photo/img10.jpg' },
                { id: 8, title: 'Новина 8', image: 'photo/img11.jpg' },
                { id: 9, title: 'Новина 9', image: 'photo/img12.jpg' },
                { id: 10, title: 'Новина 10', image: 'photo/img13.jpg' },
                { id: 11, title: 'Новина 11', image: 'photo/img14.jpg' },
                { id: 12, title: 'Новина 12', image: 'photo/img15.jpg' }
            ]
        }
    },
    
    computed: {
        paginatedNews() {
            const start = (this.currentPage - 1) * this.pageSize;
            return this.newsList.slice(start, start + this.pageSize);
        },
        totalPages() {
            return Math.ceil(this.newsList.length / this.pageSize);
        }
    },
}).mount('#app');