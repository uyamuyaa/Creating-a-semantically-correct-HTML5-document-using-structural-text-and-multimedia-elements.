export default {
    props: ['item'],
    template: `
        <div class="gallery-card">
            <img :src="item.image" :alt="item.title">
            <h3>{{ item.title }}</h3>
        </div>
    `
};